package br.com.fiap.gs.apmd.posto;

import br.com.fiap.gs.apmd.posto.view.Janela;

public class App {
	
	public static void main(String[] args) {
		new Janela().init();
	}

}
